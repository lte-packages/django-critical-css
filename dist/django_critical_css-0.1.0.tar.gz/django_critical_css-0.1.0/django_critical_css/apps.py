from django.apps import AppConfig

class DjangoCriticalCssConfig(AppConfig):
    name = 'django_critical_css'