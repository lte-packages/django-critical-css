# django_critical_css

A Django app for managing and injecting critical CSS into your templates.

## Installation

```bash
pip install .
```

## Usage

Add `django_critical_css` to your `INSTALLED_APPS` in `settings.py`.
